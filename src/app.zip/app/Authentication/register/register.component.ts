import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/shared/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
service: any;

  constructor(private userService:UserService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
  }

  // onSignUp(form:NgForm){
  //   this.userService.signUp(form.value).subscribe({
  //     next: () => {
  //         this.router.navigate(['../login'], { relativeTo: this.route });
  //     }
  // })}

  onSubmit(){
    this.userService.signUp().subscribe(
      res=>{},
      err=>{console.log(err);
      }
    )
  }


}
