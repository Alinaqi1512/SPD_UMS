import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { BehaviorSubject, map } from "rxjs";
import { UserModel } from "./user.model";

@Injectable({
    providedIn:'root'
})
export class UserService{
    // user = new BehaviorSubject<UserModel>(null);
  
    constructor(private http :HttpClient, private fb:FormBuilder){}

   formModel= this.fb.group({
    Username:['', Validators.required],
    Email:['',Validators.required],
    Gender:['', Validators.required],
    Phonenumber:['',Validators.required],
    Password:['',Validators.required]
   })
    
    signUp(){

        var body = {
            Username: this.formModel.value.Username,
            Email: this.formModel.value.Email,
            Gender: this.formModel.value.Gender,
            Phonenumber: this.formModel.value.Phonenumber,
            Password: this.formModel.value.Password,
        }
        return this.http.post('https://localhost:7037/api/Authenticate/register', body);
    }

    login(email, password){
       return this.http.post<UserModel>('https://localhost:7037/api/Authenticate/login', {
            email: email,
            password: password
        }).pipe(map(user=>{
           
        }));
    }


}