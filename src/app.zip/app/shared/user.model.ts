export class UserModel{
    public id:number;
    public name: string;
    public phonenumber: number;
    public gerder:string;
    public email: string;
    public password: string;
}